package com.flight.fligh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
