package com.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.BookFlightResponseDto;
import com.flight.dto.FlightSearchDto;
import com.flight.dto.InventoryRequestDto;
import com.flight.service.FlightSearchService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/search")
public class FlightSearchController {

@Autowired
FlightSearchService flightSearchService;
	
	@GetMapping("/{fromPlcae}/{toPlace}")
	public ResponseEntity<BookFlightResponseDto> bookFlight(@PathVariable String fromPlcae,@PathVariable String toPlace){
		BookFlightResponseDto response = new BookFlightResponseDto();
		FlightSearchDto dto = new FlightSearchDto();
		dto.setFromLocation(fromPlcae);
		dto.setToLocation(toPlace);
		List<InventoryRequestDto> list=flightSearchService.searchFlight(dto);
		response.setFlightResponse(list);
		return new ResponseEntity<BookFlightResponseDto>(response, HttpStatus.OK);
	}
}
