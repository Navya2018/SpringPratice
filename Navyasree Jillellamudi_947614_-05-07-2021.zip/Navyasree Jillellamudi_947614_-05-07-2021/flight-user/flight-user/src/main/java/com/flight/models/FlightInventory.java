package com.flight.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table
public class FlightInventory {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long id;
		
        private String flightNumber;
		@ManyToMany
		@JoinTable(
		        name = "Inventory_AirLines", 
		        joinColumns = { @JoinColumn(name = "inventory_id") }, 
		        inverseJoinColumns = { @JoinColumn(name = "airline_id") }
		    )
        private List<AirLines> airline;
	     private String fromPlace;
		private String toPlace; 
		
		private Long ticketCost;// (consider taxes and other charges), 
		private Long totalSeats;
		private String meal; //(none, veg, non veg)
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getFlightNumber() {
			return flightNumber;
		}
		public void setFlightNumber(String flightNumber) {
			this.flightNumber = flightNumber;
		}
		
		public List<AirLines> getAirline() {
			return airline;
		}
		public void setAirline(List<AirLines> airline) {
			this.airline = airline;
		}
		public String getFromPlace() {
			return fromPlace;
		}
		public void setFromPlace(String fromPlace) {
			this.fromPlace = fromPlace;
		}
		public String getToPlace() {
			return toPlace;
		}
		public void setToPlace(String toPlace) {
			this.toPlace = toPlace;
		}
		
		public Long getTicketCost() {
			return ticketCost;
		}
		public void setTicketCost(Long ticketCost) {
			this.ticketCost = ticketCost;
		}
		
		public String getMeal() {
			return meal;
		}
		public void setMeal(String meal) {
			this.meal = meal;
		}
		public Long getTotalSeats() {
			return totalSeats;
		}
		public void setTotalSeats(Long totalSeats) {
			this.totalSeats = totalSeats;
		}

	
	
}
