package com.flight.models;

public enum Status {

	ACTIVE,
	BLOCK,
	CANCELLED,
	VEG,
	NONVEG;
}
