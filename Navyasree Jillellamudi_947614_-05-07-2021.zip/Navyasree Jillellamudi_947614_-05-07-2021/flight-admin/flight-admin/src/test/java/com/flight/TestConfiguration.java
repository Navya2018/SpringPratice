//package com.flight;
//
//import org.mockito.Mockito;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//
//import com.flight.service.AirLineService;
//
//Profile("test")
//@Configuration
//public class TestConfiguration {
//   @Bean
//   @Primary
//   public AirLineService productService() {
//      return Mockito.mock(AirLineService.class);
//   }
//}
