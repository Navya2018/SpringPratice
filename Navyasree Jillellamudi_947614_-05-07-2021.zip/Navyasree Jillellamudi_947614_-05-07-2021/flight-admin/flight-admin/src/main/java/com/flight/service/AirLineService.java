package com.flight.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.dao.AirLineRepo;
import com.flight.dto.AirLineDto;
import com.flight.models.AirLines;

@Service
@Transactional
public class AirLineService {

	@Autowired
	AirLineRepo repo;
	
	
	public void addAirLine(AirLineDto dto) {
	
		if(dto.getId() != null) {
			AirLines air = repo.findById(dto.getId()).get();
			air.setContactAdress(dto.getContactAdress());
			air.setContactNumber(dto.getContactNumber());
			air.setLogo(dto.getLogo());
			air.setName(dto.getName());
			air.setStatus(dto.getStatus());
			repo.save(air);

		}else {
			AirLines air = new AirLines();
			air.setContactAdress(dto.getContactAdress());
			air.setContactNumber(dto.getContactNumber());
			air.setLogo(dto.getLogo());
			air.setName(dto.getName());
			air.setStatus(dto.getStatus());
			repo.save(air);
	
		}
				
	}


	public List<AirLineDto> getAllAirLines() {
		// TODO Auto-generated method stub

		List<AirLineDto> dtoList = new ArrayList<AirLineDto>();
		List<AirLines> airList = new ArrayList<AirLines>();
		Iterable<AirLines> iterable = repo.findAll();
		iterable.forEach(airList::add);
		for (AirLines air : airList) {
			AirLineDto dto = new AirLineDto();
			dto.setId(air.getId());
			dto.setContactAdress(air.getContactAdress());
			dto.setContactNumber(air.getContactNumber());
			dto.setLogo(air.getLogo());
			dto.setName(air.getName());
			dto.setStatus(air.getStatus());
			dtoList.add(dto);
		}
		return dtoList;
	}


	public void deleteAirLine(Long airId) {
		
		repo.deleteById(airId);
		
	}
}
