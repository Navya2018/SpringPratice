package com.flight.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.LoginRequest;
import com.flight.dto.Response;

@RestController
@RequestMapping(value = "/api/v1.0/flight/booking")
public class BookingController {
	
	
	@PostMapping("/{flightId}")
	public Response login(@RequestBody LoginRequest dtoz, @PathVariable Long flightId) {
		
		return new Response("SUCCESS", 200L, "Login Success");
		
	}

}
