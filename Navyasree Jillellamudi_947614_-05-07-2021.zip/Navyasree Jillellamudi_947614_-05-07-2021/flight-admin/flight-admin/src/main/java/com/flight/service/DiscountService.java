package com.flight.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.dao.DiscountRepo;
import com.flight.dto.DiscountDto;
import com.flight.models.Discount;

@Service
@Transactional
public class DiscountService {

	@Autowired
	DiscountRepo repo;

	public void addDiscount(DiscountDto dto) {
		Discount dis = new Discount();
		dis.setDiscountPercentage(dto.getDiscountPercentage());
		dis.setExpiryDate(dto.getExpiryDate());
		dis.setName(dto.getName());
		repo.save(dis);
	}

	public List<DiscountDto> getAllDicounts() {
		 List<DiscountDto> disList = new LinkedList<>();
		 List<Discount> list = new ArrayList<Discount>();
			Iterable<Discount> iterable = repo.findAll();
			iterable.forEach(list::add);
		for(Discount dis : list) {
			DiscountDto dto = new DiscountDto();
			dto.setDiscountPercentage(dis.getDiscountPercentage());
			dto.setExpiryDate(dis.getExpiryDate());
			dto.setName(dis.getName());
			dto.setId(dis.getId());
			disList.add(dto);
		}
		return disList;
	}

	public void delete(Long id) {
		repo.deleteById(id);
		
	}

	
}
