package com.flight.dto;

import java.util.ArrayList;
import java.util.List;

public class InventoryResponse extends Response{

	private List<InventoryRequestDto> list = new ArrayList<InventoryRequestDto>();

	public List<InventoryRequestDto> getList() {
		return list;
	}

	public void setList(List<InventoryRequestDto> list) {
		this.list = list;
	}
	
}
