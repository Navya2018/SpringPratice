package com.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.DiscountDto;
import com.flight.dto.DiscountResponseDto;
import com.flight.dto.Response;
import com.flight.service.DiscountService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/discount")
public class DiscountController {

	@Autowired
	DiscountService service;
	
	@PostMapping
	public Response addDiscount(@RequestBody DiscountDto dto) {
		try {
			service.addDiscount(dto);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	@GetMapping
	public ResponseEntity<DiscountResponseDto> listDiscounts() {
		DiscountResponseDto response = new DiscountResponseDto();
		try {
			response.setList(service.getAllDicounts());
			return new ResponseEntity<DiscountResponseDto>(response, HttpStatus.OK);
			
		}catch (Exception e) {
			return new ResponseEntity<DiscountResponseDto>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@GetMapping("/{id}")
//	 @CacheEvict(key="#id")
	public Response delete(@PathVariable Long id) {
		try {
			service.delete(id);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	
}
