package com.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.InventoryRequestDto;
import com.flight.dto.InventoryResponse;
import com.flight.dto.Response;
import com.flight.service.InventoryService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/inventory")
public class InventoryController {

	@Autowired
	InventoryService inventoryService;
	
	@PostMapping
	public Response addInventory(@RequestBody InventoryRequestDto dto) {
		try {
			inventoryService.addInventory(dto);
			return new Response("SUCCESS", 200L, "Success");

		} catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");

		}
	}

	@GetMapping
	public ResponseEntity<InventoryResponse> listInventory() {
		InventoryResponse response = new InventoryResponse();
		try {
			response.setList(inventoryService.listInventory());

			return new ResponseEntity<InventoryResponse>(response, HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<InventoryResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/{id}")
	public Response delete(@PathVariable Long id) {
		try {
			inventoryService.delete(id);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	
}
