package com.flight.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class FlightInventory {

	
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long id;
		
        private String flightNumber;
		
        private Long airlineId;
	     private String fromPlace;
		private String toPlace; 
		private Long ticketCost;// (consider taxes and other charges), 
		private Long totalSeats;
		private String meal; //(none, veg, non veg)
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getFlightNumber() {
			return flightNumber;
		}
		public void setFlightNumber(String flightNumber) {
			this.flightNumber = flightNumber;
		}
		
		public Long getAirlineId() {
			return airlineId;
		}
		public void setAirlineId(Long airlineId) {
			this.airlineId = airlineId;
		}
		public String getFromPlace() {
			return fromPlace;
		}
		public void setFromPlace(String fromPlace) {
			this.fromPlace = fromPlace;
		}
		public String getToPlace() {
			return toPlace;
		}
		public void setToPlace(String toPlace) {
			this.toPlace = toPlace;
		}
		
		public Long getTicketCost() {
			return ticketCost;
		}
		public void setTicketCost(Long ticketCost) {
			this.ticketCost = ticketCost;
		}
		
		public String getMeal() {
			return meal;
		}
		public void setMeal(String meal) {
			this.meal = meal;
		}
		public Long getTotalSeats() {
			return totalSeats;
		}
		public void setTotalSeats(Long totalSeats) {
			this.totalSeats = totalSeats;
		}

	
	
}
