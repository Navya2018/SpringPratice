package com.flight.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.flight.service.UserDetailsServiceImpl;

public class JwtAuthTokenFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProvider tokenProvider;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthTokenFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, 
    								HttpServletResponse response, 
    								FilterChain filterChain) 
    										throws ServletException, IOException {
        try {
        	
//        	response.setHeader("Access-Control-Allow-Origin", "*");

        	  // Request methods you wish to allow
        	response.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");

        	  // Request headers you wish to allow
        	response.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,X-Access-Token,XKey,Authorization");


        	String requestURI=request.getRequestURI();
//        	requestURI=requestURI.replaceAll("/api", "").trim();
        	if(requestURI.contains("/login") ||requestURI.contains("/register") || requestURI.contains("swagger-ui.html")|| requestURI.contains("webjars")
        			|| requestURI.contains("v2") || requestURI.contains("swagger-resources") || requestURI.equals("/") || requestURI.contains("configuration") || requestURI.contains("images")) { 
        		filterChain.doFilter(request, response);
        	}else {
        	      String jwt = getJwt(request);
                  if (jwt!=null && tokenProvider.validateJwtToken(jwt)) {
                      String username = tokenProvider.getUserNameFromJwtToken(jwt);

                      UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                      UsernamePasswordAuthenticationToken authentication 
                      		= new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                      authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                      SecurityContextHolder.getContext().setAuthentication(authentication);
                  }
                  filterChain.doFilter(request, response);
        	}
              } catch (Exception e) {
    	
            logger.error("Can NOT set user authentication -> Message: {}", e);
        }
 
    }

    private String getJwt(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        	
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
        	return authHeader.replace("Bearer ","");
        }

        return null;
    }
}
