package com.flight.dto;

import java.util.Date;
import java.util.List;

import com.flight.models.Status;

public class BookFlightDto {

	private Long id;
	private Long userId;
	private Long airLineId;
	private Date jouneryDate;
	private Date bookingDate;
	private Double bookingAmount;
	private Long numberOfSeates;
	private Status status;
	private List<PassengerDto> passenger;
	private String pnrNumber;
	private String meal;

	private String emailId;
	private String firstName;
	private String lastName;;
	private Long noOfSeatsToBook;
	private Long seatNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAirLineId() {
		return airLineId;
	}

	public void setAirLineId(Long airLineId) {
		this.airLineId = airLineId;
	}

	public Date getJouneryDate() {
		return jouneryDate;
	}

	public void setJouneryDate(Date jouneryDate) {
		this.jouneryDate = jouneryDate;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Double getBookingAmount() {
		return bookingAmount;
	}

	public void setBookingAmount(Double bookingAmount) {
		this.bookingAmount = bookingAmount;
	}

	public Long getNumberOfSeates() {
		return numberOfSeates;
	}

	public void setNumberOfSeates(Long numberOfSeates) {
		this.numberOfSeates = numberOfSeates;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public List<PassengerDto> getPassenger() {
		return passenger;
	}

	public void setPassenger(List<PassengerDto> passenger) {
		this.passenger = passenger;
	}

	public String getPnrNumber() {
		return pnrNumber;
	}

	public void setPnrNumber(String pnrNumber) {
		this.pnrNumber = pnrNumber;
	}

	public String getMeal() {
		return meal;
	}

	public void setMeal(String meal) {
		this.meal = meal;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getNoOfSeatsToBook() {
		return noOfSeatsToBook;
	}

	public void setNoOfSeatsToBook(Long noOfSeatsToBook) {
		this.noOfSeatsToBook = noOfSeatsToBook;
	}

	public Long getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(Long seatNo) {
		this.seatNo = seatNo;
	}

}
