package com.flight.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.flight.models.BookingHistory;

@Repository
public interface BookFlightRepo extends CrudRepository<BookingHistory, Long> {

	List<BookingHistory> findBookHistoryByEmailId(String email);
	
	BookingHistory findBookHistoryByPnrNumber(String pnrNumber);
}
