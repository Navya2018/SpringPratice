package com.flight.dto;

import java.util.ArrayList;
import java.util.List;

public class BookFlightHistoryResponseDto extends Response{

	private List<BookFlightDto> history = new ArrayList<BookFlightDto>();

	public List<BookFlightDto> getHistory() {
		return history;
	}

	public void setHistory(List<BookFlightDto> history) {
		this.history = history;
	}
	
}
