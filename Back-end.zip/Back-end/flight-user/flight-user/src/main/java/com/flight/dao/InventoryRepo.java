package com.flight.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.flight.models.FlightInventory;

@Repository
public interface InventoryRepo extends CrudRepository<FlightInventory, Long> {

	@Query(nativeQuery = true , value = "select * from flight_inventory  where from_place =:fromLocation and to_place=:toLocation ")
	List<FlightInventory> searchFlight( String fromLocation, String toLocation);

}
