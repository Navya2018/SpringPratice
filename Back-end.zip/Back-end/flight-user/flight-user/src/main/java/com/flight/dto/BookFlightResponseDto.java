package com.flight.dto;

import java.util.ArrayList;
import java.util.List;

public class BookFlightResponseDto extends Response {

	List<InventoryRequestDto> flightResponse = new ArrayList<InventoryRequestDto>();

	public List<InventoryRequestDto> getFlightResponse() {
		return flightResponse;
	}

	public void setFlightResponse(List<InventoryRequestDto> flightResponse) {
		this.flightResponse = flightResponse;
	}
	
}
