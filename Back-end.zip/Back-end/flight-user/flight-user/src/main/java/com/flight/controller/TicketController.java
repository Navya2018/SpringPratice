package com.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.BookFlightDto;
import com.flight.service.BookFlightService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/ticket")
public class TicketController {

	@Autowired
	BookFlightService bookFlightService;
	
	@GetMapping("/pnr")
	public ResponseEntity<?> getTicketDetails(@PathVariable String pnr){
		BookFlightDto s = bookFlightService.getTicketDetails(pnr);
		
		return new ResponseEntity<BookFlightDto>(s, HttpStatus.OK);
		

		
	}
}
