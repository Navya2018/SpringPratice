package com.flight.models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class BookingHistory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String emailId;
	private String  firstName;
	    private String lastName;
	    private String meal;
	    private Long noOfSeatsToBook; 
	    private Long seatNo;
	    private Date jouneryDate;
	    private String pnrNumber;
	    @Enumerated(EnumType.STRING)
	    private Status status;
	    
		public String getPnrNumber() {
			return pnrNumber;
		}
		public void setPnrNumber(String pnrNumber) {
			this.pnrNumber = pnrNumber;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getMeal() {
			return meal;
		}
		public void setMeal(String meal) {
			this.meal = meal;
		}
		public Long getNoOfSeatsToBook() {
			return noOfSeatsToBook;
		}
		public void setNoOfSeatsToBook(Long noOfSeatsToBook) {
			this.noOfSeatsToBook = noOfSeatsToBook;
		}
		public Long getSeatNo() {
			return seatNo;
		}
		public void setSeatNo(Long seatNo) {
			this.seatNo = seatNo;
		}
		public Date getJouneryDate() {
			return jouneryDate;
		}
		public void setJouneryDate(Date jouneryDate) {
			this.jouneryDate = jouneryDate;
		}
		public Status getStatus() {
			return status;
		}
		public void setStatus(Status status) {
			this.status = status;
		}
	
	    
}
