package com.flight.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.flight.dao.BookFlightRepo;
import com.flight.dto.BookFlightDto;
import com.flight.models.BookingHistory;
import com.flight.models.Status;

@Service
@Transactional
public class BookFlightService {

	@Autowired
	BookFlightRepo repo;

	
	@Autowired
	private KafkaTemplate<String, BookingHistory> kafkaTemplate;

	private static final String TOPIC = "demo";

	

	public boolean bookFlight(BookFlightDto dto, Long flightId) {
		BookingHistory book = new BookingHistory();
		book.setEmailId(dto.getEmailId());
		book.setFirstName(dto.getFirstName());
		book.setLastName(dto.getLastName());
		book.setMeal(dto.getMeal());
		book.setNoOfSeatsToBook(dto.getNoOfSeatsToBook());
		book.setSeatNo(dto.getSeatNo());
		 kafkaTemplate.send(TOPIC, book);
		repo.save(book);
		return true;
	}

	public List<BookFlightDto> getFlightHistory(String emailId) {
		List<BookingHistory> list=repo.findBookHistoryByEmailId(emailId);
		 List<BookFlightDto>  res= new ArrayList<BookFlightDto>();
		for(BookingHistory dto:list) {
			BookFlightDto book = new BookFlightDto();
			book.setEmailId(dto.getEmailId());
			book.setFirstName(dto.getFirstName());
			book.setLastName(dto.getLastName());
			book.setMeal(dto.getMeal());
			book.setNoOfSeatsToBook(dto.getNoOfSeatsToBook());
			book.setSeatNo(dto.getSeatNo());
			res.add(book);
		}
		return res;
	}

	public boolean cancelTicketOnPnr(String pnr) {
		BookingHistory book=repo.findBookHistoryByPnrNumber(pnr);
		if(book.getJouneryDate().before(new Date())) {
		book.setStatus(Status.CANCELLED);
		repo.save(book);
		return true;
		}else {
			return false;
		}
	}

	public BookFlightDto getTicketDetails(String pnr) {
		BookingHistory dto=repo.findBookHistoryByPnrNumber(pnr);
		BookFlightDto book = new BookFlightDto();
//		book.setAirLineId(dto.getAirLineId());
//		book.setBookingAmount(dto.getBookingAmount());
//		book.setBookingDate(dto.getBookingDate());
//		book.setJouneryDate(dto.getJounerDate());
//		book.setNumberOfSeates(dto.getNumberOfSeates());
		return book;
	}
	
	
}
