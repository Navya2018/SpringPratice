package com.flight.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.dao.InventoryRepo;
import com.flight.dto.FlightSearchDto;
import com.flight.dto.InventoryRequestDto;
import com.flight.models.FlightInventory;

@Service
@Transactional
public class FlightSearchService {

	@Autowired
	InventoryRepo repo;
	
	public List<InventoryRequestDto> searchFlight(FlightSearchDto req) {
	List<FlightInventory> list=	repo.searchFlight(req.getFromLocation(),req.getToLocation());
	List<InventoryRequestDto> dtosList = new ArrayList<InventoryRequestDto>();
	for(FlightInventory dto : list) {
		InventoryRequestDto inv = new InventoryRequestDto();
		inv.setFlightNumber(dto.getFlightNumber());
		inv.setFromPlace(dto.getFromPlace());
		inv.setToPlace(dto.getToPlace());
		inv.setTicketCost(dto.getTicketCost());
		inv.setMeal(dto.getMeal());
		inv.setTotalSeats(dto.getTotalSeats());
		inv.setId(dto.getId());
		dtosList.add(inv);
	}
		return dtosList;
	}

	
}
