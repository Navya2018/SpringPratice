package com.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.BookFlightDto;
import com.flight.dto.BookFlightHistoryResponseDto;
import com.flight.dto.Response;
import com.flight.service.BookFlightService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/book")
public class BookFlightController {

	@Autowired
	BookFlightService bookFlightService;
	
	
	@PostMapping("/{id}")
	public ResponseEntity<Response> bookFlight(@RequestBody BookFlightDto dto, @PathVariable Long id){
		boolean response = bookFlightService.bookFlight(dto,id);
		System.out.println(response);
		return new ResponseEntity<Response>(new Response("SUCCESS", 200L, "Success"), HttpStatus.OK);
	}
	
	@GetMapping("/history/{emailId}")
	public ResponseEntity<BookFlightHistoryResponseDto> flightHistory(@PathVariable String emailId){
		BookFlightHistoryResponseDto response = new BookFlightHistoryResponseDto();
		response.setHistory(bookFlightService.getFlightHistory(emailId));
		return new ResponseEntity<BookFlightHistoryResponseDto>(response, HttpStatus.OK);
	}
	
	@GetMapping("/cancel/{pnr}")
	public ResponseEntity<Response> cancelTicketBasedOnPnr(@PathVariable String pnr){
		boolean res = bookFlightService.cancelTicketOnPnr(pnr);
		if(res)
		return new ResponseEntity<Response>(new Response("SUCCESS", 200L, "Success"), HttpStatus.INTERNAL_SERVER_ERROR);
		else
			return new ResponseEntity<Response>(new Response("FAILED", 200L, "Unable to cancel the ticket"), HttpStatus.INTERNAL_SERVER_ERROR);

	}
}
