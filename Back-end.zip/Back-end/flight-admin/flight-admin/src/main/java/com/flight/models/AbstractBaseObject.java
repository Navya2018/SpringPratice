package com.flight.models;

import java.util.Date;

public class AbstractBaseObject {

	private Date createdOn;
	private Long createdBy;
	private Long rowStatus;
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getRowStatus() {
		return rowStatus;
	}
	public void setRowStatus(Long rowStatus) {
		this.rowStatus = rowStatus;
	}
	 
	
}
