package com.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dto.AirLineDto;
import com.flight.dto.AirLineResponseDto;
import com.flight.dto.Response;
import com.flight.service.AirLineService;

@RestController
@RequestMapping(value = "/api/v1.0/flight/airline")
public class AirLineController {

	@Autowired
	AirLineService airLineService;
	
	@PostMapping
//	@Cacheable
	public Response addAirLine(@RequestBody AirLineDto dto) {
		try {
			airLineService.addAirLine(dto);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	
	@PutMapping
	@Cacheable
	public Response updateAirLine(@RequestBody AirLineDto dto) {
		try {
			airLineService.addAirLine(dto);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	
	@GetMapping
	public ResponseEntity<AirLineResponseDto> listAirLine() {
		AirLineResponseDto response = new AirLineResponseDto();
		try {
			response.setDtoList(airLineService.getAllAirLines());
			return new ResponseEntity<AirLineResponseDto>(response, HttpStatus.OK);
			
		}catch (Exception e) {
			return new ResponseEntity<AirLineResponseDto>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@GetMapping("/{id}")
//	 @CacheEvict(key="#id")
	public Response deleteAirLine(@PathVariable Long id) {
		try {
			airLineService.deleteAirLine(id);
			return new Response("SUCCESS", 200L, "Success");
			
		}catch (Exception e) {
			return new Response("ERROR", 500L, "Internal Server Error");
		}
		
	}
	
}
