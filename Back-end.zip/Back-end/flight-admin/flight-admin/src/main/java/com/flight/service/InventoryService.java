package com.flight.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.dao.InventoryRepo;
import com.flight.dto.InventoryRequestDto;
import com.flight.models.FlightInventory;

@Service
@Transactional
public class InventoryService {

	@Autowired
	InventoryRepo repo;

	public void addInventory(InventoryRequestDto dto) {
		FlightInventory inv = new FlightInventory();
		inv.setFlightNumber(dto.getFlightNumber());
		inv.setFromPlace(dto.getFromPlace());
		inv.setToPlace(dto.getToPlace());
		inv.setTicketCost(dto.getTicketCost());
		inv.setMeal(dto.getMeal());
		inv.setTotalSeats(dto.getTotalSeats());
		inv.setAirlineId(dto.getAirline());
		repo.save(inv);
	}

	public List<InventoryRequestDto> listInventory() {
		List<InventoryRequestDto> dtoList = new ArrayList<InventoryRequestDto>();
		List<FlightInventory> airList = new ArrayList<FlightInventory>();
		Iterable<FlightInventory> iterable = repo.findAll();
		iterable.forEach(airList::add);
		for (FlightInventory dto : airList) {
			InventoryRequestDto inv = new InventoryRequestDto();
			inv.setId(dto.getId());
			inv.setFlightNumber(dto.getFlightNumber());
			inv.setFromPlace(dto.getFromPlace());
			inv.setToPlace(dto.getToPlace());
			inv.setTicketCost(dto.getTicketCost());
			inv.setMeal(dto.getMeal());
			inv.setTotalSeats(dto.getTotalSeats());
			inv.setAirline(dto.getAirlineId());
			dtoList.add(inv);
		}
		return dtoList;
		
	}

	public void delete(Long id) {
		repo.deleteById(id);
		
	}
	
	
	
	
}
