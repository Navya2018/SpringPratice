package com.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableWebMvc
@EnableCaching
@EnableKafka
public class FlightAdminApplication implements WebMvcConfigurer {

	@Bean
	@LoadBalanced
	public RestTemplate getResRestTemplate() {
		return new RestTemplate();
	}
	
	  @Override
      public void addCorsMappings(CorsRegistry registry) {
      registry.addMapping("/**").allowedMethods("GET","POST","OPTIONs");
      }
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
	public static void main(String[] args) {
		SpringApplication.run(FlightAdminApplication.class, args);
	}

}
