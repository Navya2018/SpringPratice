package com.flight.dto;

import java.util.List;

import java.util.ArrayList;

public class AirLineResponseDto extends Response {

	private List<AirLineDto> dtoList = new ArrayList<AirLineDto>();

	public List<AirLineDto> getDtoList() {
		return dtoList;
	}

	public void setDtoList(List<AirLineDto> dtoList) {
		this.dtoList = dtoList;
	}
	
}
