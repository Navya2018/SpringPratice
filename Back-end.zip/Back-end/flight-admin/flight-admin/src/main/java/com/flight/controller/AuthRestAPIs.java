package com.flight.controller;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.dao.RoleRepository;
import com.flight.dao.UserRepository;
import com.flight.dto.JwtResponse;
import com.flight.dto.LoginForm;
import com.flight.dto.Response;
import com.flight.dto.SignUpForm;
import com.flight.jwt.JwtProvider;
import com.flight.models.Role;
import com.flight.models.User;

//@CrossOrigin
@RestController
@RequestMapping("/api/v1.0/flight/user")
public class AuthRestAPIs {


    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser( @RequestBody LoginForm loginRequest) {
    	try {
    	User user=userRepository.findByEmail(loginRequest.getUsername()).get();
    	if(user != null) {
    		if(BCrypt.checkpw(loginRequest.getPassword(), user.getPassword())){
    			String jwt = jwtProvider.generateJwtToken(loginRequest.getUsername());
    	        return ResponseEntity.ok(new JwtResponse(jwt,user.getName(),user.getEmail(),user.getRoles().iterator().next().getName()));
    		}else {
    			return new ResponseEntity<Response>(new Response("ERROR", 500L, "Invalid crendtials"), HttpStatus.INTERNAL_SERVER_ERROR);
    		}
    		  
    	}else {
    		return new ResponseEntity<Response>(new Response("ERROR", 500L, "User Does not exist"), HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	}catch (Exception e) {
    		return new ResponseEntity<Response>(new Response("ERROR", 500L, "User Does not exist"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
      
    }

    @PostMapping("/register")
    public ResponseEntity<Response> registerUser(@RequestBody SignUpForm signUpRequest) {
        if(userRepository.existsByEmail(signUpRequest.getUsername())) {
            return new ResponseEntity<Response>(new Response("BAD_REQ",500L, "Fail -> Username is already taken!"),
                    HttpStatus.BAD_REQUEST);
        }

        // Creating user's account
        User user = new User(signUpRequest.getName(),
                signUpRequest.getUsername(), encoder.encode(signUpRequest.getPassword()));


        Role role = roleRepository.findByName(signUpRequest.getRole());
        HashSet<Role> rr = new HashSet<Role>();
        rr.add(role);
        user.setRoles(rr);
       user.setLogin(false);
        userRepository.save(user);

        return ResponseEntity.ok().body(new Response("SCCESS",200L, "User registered successfully!"));
    }
}