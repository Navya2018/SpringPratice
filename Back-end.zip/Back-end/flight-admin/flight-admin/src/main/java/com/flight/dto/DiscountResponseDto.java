package com.flight.dto;

import java.util.ArrayList;
import java.util.List;

public class DiscountResponseDto extends Response{

	private List<DiscountDto> list = new ArrayList<DiscountDto>();

	public List<DiscountDto> getList() {
		return list;
	}

	public void setList(List<DiscountDto> list) {
		this.list = list;
	}
	
	
	
}
