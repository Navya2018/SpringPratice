package com.flight.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.flight.models.FlightInventory;

@Repository
public interface InventoryRepo extends  CrudRepository<FlightInventory, Long> {

}
