package com.flight.dto;

public class JwtResponse {
    private String token;
    private String type = "Bearer";
    private String user;
    private String username;
    private String role;
    

    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public JwtResponse(String accessToken,String user,String username , String role) {
        this.token = accessToken;
        this.user=user;
        this.role=role;
        this.username=username;
    }

    public String getAccessToken() {
        return token;
    }

    public void setAccessToken(String accessToken) {
        this.token = accessToken;
    }

    public String getTokenType() {
        return type;
    }

    public void setTokenType(String tokenType) {
        this.type = tokenType;
    }
}