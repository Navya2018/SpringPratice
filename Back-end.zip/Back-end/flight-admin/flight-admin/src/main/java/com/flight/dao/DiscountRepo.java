package com.flight.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.flight.models.Discount;

@Repository
public interface DiscountRepo  extends CrudRepository<Discount, Long>{

	
}
