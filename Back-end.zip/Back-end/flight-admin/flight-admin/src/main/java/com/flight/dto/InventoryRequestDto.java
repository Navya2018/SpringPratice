package com.flight.dto;

public class InventoryRequestDto {

	private Long id;
    private String flightNumber;
    private Long airline;
     private String fromPlace;
	private String toPlace;
	private Long ticketCost;// (consider taxes and other charges), 
	private Long totalSeats;;
	private String meal;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	
	public Long getAirline() {
		return airline;
	}
	public void setAirline(Long airline) {
		this.airline = airline;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	
	public Long getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(Long ticketCost) {
		this.ticketCost = ticketCost;
	}

	
	public Long getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(Long totalSeats) {
		this.totalSeats = totalSeats;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	
	
}
