package com.flight;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.flight.dao.AirLineRepo;
import com.flight.models.AirLines;
import com.flight.service.AirLineService;

@RunWith(SpringRunner.class)
@SpringBootTest
class FlightAdminApplicationTests {

	@Autowired
	private AirLineService airService;
	
	@MockBean
	private AirLineRepo airRepo;
	@Autowired
	private AirLineRepo repo;
	
	@Test
	public void getAirLinesTest() {
		when(airRepo.findAll()).thenReturn(Stream.of(new AirLines(1L, "Airindia", "Hyderabad", "9198667448"))
				.collect(Collectors.toList()));
		assertEquals(1, airService.getAllAirLines().size());
	}
	
	@Test
	void saveAirlineTest() {
		AirLines air= new AirLines(3L, "JetAir", "Pune", "9998888777");
		when(airRepo.save(air)).thenReturn(air);
		assertEquals(air, repo.save(air));
	}
	
	@Test
	void deleteAirlineTest() {
		AirLines air= new AirLines(3L, "JetAir", "Pune", "9998888777");
		repo.delete(air);
		verify(airRepo, times(1)).delete(air);
	}

}
