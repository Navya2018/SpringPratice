package com.flight.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

@Component
@Primary
public class SwaggerConfig extends WebMvcConfigurationSupport implements SwaggerResourcesProvider{

	@Override
	public List<SwaggerResource> get() {
		List<SwaggerResource> res = new ArrayList<SwaggerResource>();
		res.add(swaggerResource("Admin app","/admin-service/v2/api-docs","2.0"));
		res.add(swaggerResource("User app","/user-service/v2/api-docs","2.0"));
		return res;
	}
	
	private SwaggerResource swaggerResource(String s1, String s2, String s3) {
		SwaggerResource ss = new SwaggerResource();
		ss.setName(s1);
		ss.setLocation(s2);
		ss.setSwaggerVersion(s3);
		return ss;
	}

	  protected void addResourceHandlers(ResourceHandlerRegistry registry) {
	        registry.addResourceHandler("swagger-ui.html")
	                .addResourceLocations("classpath:/META-INF/resources/");
	        registry.addResourceHandler("/webjars/**")
	        .addResourceLocations("classpath:/META-INF/resources/webjars/");
	    }
}
